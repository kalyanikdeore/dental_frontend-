// pages/GalleryPage.jsx
import React, { useState, useEffect } from "react";
import { useParams, useLocation } from "react-router-dom";
import { motion } from "framer-motion";
import { fadeIn } from "../../utils/motion";
import { ChevronLeft, ChevronRight, X, MapPin, Phone } from "lucide-react";
import { useSEO } from "../../hooks/useSEO";
import axiosInstance from "../../services/api";

const GalleryPage = () => {
  const location = useLocation();
  const { clinicId } = useParams();

  // Extract clinic ID from URL pathname if useParams doesn't work
  const pathname = location.pathname;
  const extractedClinicId = clinicId || pathname.split("/").pop();

  const [selectedImage, setSelectedImage] = useState(null);
  const [lightboxIndex, setLightboxIndex] = useState(0);
  const [clinic, setClinic] = useState(null);
  const [categories, setCategories] = useState([]);
  const [filteredImages, setFilteredImages] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState("All");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Fetch gallery data from backend
  useEffect(() => {
    const fetchGalleryData = async () => {
      try {
        setLoading(true);
        setError(null);

        const response = await axiosInstance.get(
          `/gallery/${extractedClinicId}`
        );

        if (response.data.success) {
          setClinic(response.data.clinic);
          setFilteredImages(response.data.images);

          // Extract unique categories
          const uniqueCategories = [
            ...new Set(response.data.images.map((image) => image.category)),
          ];
          setCategories(uniqueCategories);
        } else {
          throw new Error("Failed to fetch gallery data");
        }
      } catch (err) {
        console.error("Error fetching gallery data:", err);
        setError("Failed to load gallery. Please try again later.");

        // Fallback to empty state
        setClinic({ name: "Clinic Gallery" });
        setFilteredImages([]);
        setCategories([]);
      } finally {
        setLoading(false);
      }
    };

    if (extractedClinicId) {
      fetchGalleryData();
    }
  }, [extractedClinicId]);

  // Filter images when category changes
  useEffect(() => {
    if (clinic && clinic.images) {
      const filtered =
        selectedCategory === "All"
          ? clinic.images
          : clinic.images.filter(
              (image) => image.category === selectedCategory
            );
      setFilteredImages(filtered);
    }
  }, [selectedCategory, clinic]);

  const openLightbox = (index) => {
    setSelectedImage(filteredImages[index]);
    setLightboxIndex(index);
  };

  const closeLightbox = () => {
    setSelectedImage(null);
  };

  const navigateLightbox = (direction) => {
    let newIndex;
    if (direction === "prev") {
      newIndex =
        lightboxIndex === 0 ? filteredImages.length - 1 : lightboxIndex - 1;
    } else {
      newIndex =
        lightboxIndex === filteredImages.length - 1 ? 0 : lightboxIndex + 1;
    }
    setSelectedImage(filteredImages[newIndex]);
    setLightboxIndex(newIndex);
  };

  useSEO("gallery");

  // Loading state
  if (loading) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 mt-20">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-500 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading gallery...</p>
        </div>
      </div>
    );
  }

  // Error state
  if (error) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-92 mt-20">
        <div className="text-center text-red-500">
          <p>{error}</p>
        </div>
      </div>
    );
  }

  return (
    <motion.div
      initial="hidden"
      whileInView="show"
      viewport={{ once: true }}
      className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 mt-20"
    >
      {/* Clinic Header */}
      <motion.div
        variants={fadeIn("up", "spring", 0.1, 1)}
        className="text-center mb-8 pt-10"
      >
        <h1 className="text-4xl font-extrabold text-[#0a8583] mb-4">
          {clinic?.name || "Clinic Gallery"}
        </h1>
        <div className="w-24 h-1 bg-green-500 mx-auto"></div>
      </motion.div>

      {/* Category Filters */}
      {categories.length > 0 && (
        <motion.div
          variants={fadeIn("up", "spring", 0.2, 1)}
          className="flex flex-wrap justify-center gap-3 mb-12"
        >
          <button
            onClick={() => setSelectedCategory("All")}
            className={`px-4 py-2 rounded-full transition-colors ${
              selectedCategory === "All"
                ? "bg-green-500 text-white"
                : "bg-gray-100 text-gray-700 hover:bg-green-100"
            }`}
          >
            All
          </button>
          {categories.map((category, index) => (
            <button
              key={index}
              onClick={() => setSelectedCategory(category)}
              className={`px-4 py-2 rounded-full transition-colors ${
                selectedCategory === category
                  ? "bg-green-500 text-white"
                  : "bg-gray-100 text-gray-700 hover:bg-green-100"
              }`}
            >
              {category}
            </button>
          ))}
        </motion.div>
      )}

      {/* Gallery Grid */}
      {filteredImages.length > 0 ? (
        <motion.div
          variants={fadeIn("up", "spring", 0.3, 1)}
          className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6"
        >
          {filteredImages.map((image, index) => (
            <motion.div
              key={image.id}
              variants={fadeIn("up", "spring", index * 0.1, 1)}
              className="group relative overflow-hidden rounded-lg cursor-pointer shadow-md hover:shadow-xl transition-shadow"
              onClick={() => openLightbox(index)}
            >
              <img
                src={
                  image.src.startsWith("http")
                    ? image.src
                    : `${fileBaseURL}${image.src}`
                }
                alt={image.alt}
                className="w-full h-64 object-contain transition-transform duration-300 group-hover:scale-110 bg-gray-100"
                onError={(e) => {
                  e.target.src = "/images/placeholder.jpg"; // Fallback image
                }}
              />
              <div className="absolute inset-0 bg-opacity-0 group-hover:bg-opacity-40 transition-opacity duration-300 flex items-end">
                <div className="p-4 text-white opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <p className="font-medium">{image.alt}</p>
                  <span className="text-sm bg-green-500 px-2 py-1 rounded-full mt-2 inline-block">
                    {image.category}
                  </span>
                </div>
              </div>
            </motion.div>
          ))}
        </motion.div>
      ) : (
        <motion.div
          variants={fadeIn("up", "spring", 0.3, 1)}
          className="text-center py-12"
        >
          <p className="text-gray-500 text-lg">
            No images found for this clinic.
          </p>
        </motion.div>
      )}

      {/* Lightbox Modal */}
      {selectedImage && (
        <div className="fixed inset-0 bg-black bg-opacity-90 z-50 flex items-center justify-center p-4 object-fill">
          <button
            onClick={closeLightbox}
            className="absolute top-4 right-4 text-white hover:text-green-400 transition-colors z-10"
          >
            <X size={32} />
          </button>

          <button
            onClick={() => navigateLightbox("prev")}
            className="absolute left-4 text-white hover:text-green-400 transition-colors z-10"
          >
            <ChevronLeft size={40} />
          </button>

          <button
            onClick={() => navigateLightbox("next")}
            className="absolute right-4 text-white hover:text-green-400 transition-colors z-10"
          >
            <ChevronRight size={40} />
          </button>

          <div className="max-w-4xl max-h-full">
            <img
              src={
                selectedImage.src.startsWith("http")
                  ? selectedImage.src
                  : `${fileBaseURL}${selectedImage.src}`
              }
              alt={selectedImage.alt}
              className="max-w-full max-h-full object-contain"
              onError={(e) => {
                e.target.src = "/images/placeholder.jpg"; // Fallback image
              }}
            />
            <div className="text-white text-center mt-4">
              <p className="text-xl font-semibold">{selectedImage.alt}</p>
              <p className="text-green-400">{selectedImage.category}</p>
            </div>
          </div>
        </div>
      )}
    </motion.div>
  );
};

export default GalleryPage;
