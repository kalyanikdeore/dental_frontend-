import React from "react";

function Home2() {
  return <div>Home2</div>;
}

export default Home2;
