import React from "react";

function DeolaliCamp() {
  return <div>DeolaliCamp</div>;
}

export default DeolaliCamp;
