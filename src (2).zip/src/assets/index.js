import drLogo from "./drlogo.jpeg";
import videoHero from "./hero/herovideo.mp4";
import dental from "./doctors/dental.jpg";
import about1 from "./doctors/about1.png";
import about2 from "./doctors/about2.jpg";
import about3 from "./doctors/about3.png";
import doctorDiptiJoshi from "./doctors/DiptiJoshi.jpeg";
import doctorNikitaJoshi from "./doctors/NikitaJoshi.jpeg";
import doctorPushkarJoshi from "./doctors/PushkarJoshi.jpeg";
import doctorChinmayJoshi from "./doctors/ChinmayJoshi.jpeg";
import deolalicamptreatment1 from "./ClinicNo1DeolaliCamp/Treatment/AparnabhaleraoKidsTreatmentDrJoshi.jpeg";
import deolalicamptreatment2 from "./ClinicNo1DeolaliCamp/Treatment/AparnabhaleraoKidsTreatmentDrJoshis.jpeg";
import deolalicamptreatment3 from "./ClinicNo1DeolaliCamp/Treatment/MalvikaThakurKidsTreatmentDrJoshisCareCureDentalClinic.jpeg";
import deolalicamptreatment4 from "./ClinicNo1DeolaliCamp/Treatment/MalvikaThakurKidsTreatmentDrJoshisCareCureDentalClinic1.jpeg";
import deolalicamptreatment5 from "./ClinicNo1DeolaliCamp/Treatment/RashiSinghorthotreatmentDrJoshisCareCureDentalclinic.jpeg";
import deolalicamptreatment6 from "./ClinicNo1DeolaliCamp/Treatment/RushikeshdheringeorthodontictreatmentDrJoshisCareCureDentalClinic1.jpeg";
import deolalicamptreatment7 from "./ClinicNo1DeolaliCamp/Treatment/SheetalgaikwadDrJoshisCareCareDentalClinic.jpeg";
import deolalicamptreatment8 from "./ClinicNo1DeolaliCamp/Treatment/ShravanabhangDrJoshisCareCareDentalClinic.jpeg";
import deolalicamptreatment9 from "./ClinicNo1DeolaliCamp/Treatment/SujalPatilorthotreatmentDrJoshisCareCureDentalClinic02532496350.jpeg";

import nashikroadclinic1 from "./JoshisDentalClinicNahsikRoad/3K1A5022.JPG";
import nashikroadclinic2 from "./JoshisDentalClinicNahsikRoad/3K1A5025.JPG";
import nashikroadclinic3 from "./JoshisDentalClinicNahsikRoad/3K1A5026.JPG";
import nashikroadclinic4 from "./JoshisDentalClinicNahsikRoad/3K1A5028.JPG";
import nashikroadclinic5 from "./JoshisDentalClinicNahsikRoad/3K1A5029.JPG";
import nashikroadclinic6 from "./JoshisDentalClinicNahsikRoad/3K1A5030.JPG";
import nashikroadclinic7 from "./JoshisDentalClinicNahsikRoad/3K1A5032.JPG";
import nashikroadclinic8 from "./JoshisDentalClinicNahsikRoad/3K1A5035.JPG";
import nashikroadclinic9 from "./JoshisDentalClinicNahsikRoad/3K1A5039.JPG";
import nashikroadclinic10 from "./JoshisDentalClinicNahsikRoad/3K1A5046.JPG";
import nashikroadclinic11 from "./JoshisDentalClinicNahsikRoad/3K1A5049.JPG";
import nashikroadclinic12 from "./JoshisDentalClinicNahsikRoad/3K1A5051.JPG";
import nashikroadclinic13 from "./JoshisDentalClinicNahsikRoad/3K1A5052.JPG";
import nashikroadclinic14 from "./JoshisDentalClinicNahsikRoad/3K1A5053.JPG";
import nashikroadclinic15 from "./JoshisDentalClinicNahsikRoad/3K1A5054.JPG";
import nashikroadclinic16 from "./JoshisDentalClinicNahsikRoad/3K1A5055.JPG";
import nashikroadclinic17 from "./JoshisDentalClinicNahsikRoad/3K1A5056.JPG";
import nashikroadclinic18 from "./JoshisDentalClinicNahsikRoad/3K1A5058.JPG";
import nashikroadclinic19 from "./JoshisDentalClinicNahsikRoad/3K1A5059.JPG";
import nashikroadclinic20 from "./JoshisDentalClinicNahsikRoad/3K1A5060.JPG";
import nashikroadclinic21 from "./JoshisDentalClinicNahsikRoad/3K1A5062.JPG";
import nashikroadclinic22 from "./JoshisDentalClinicNahsikRoad/3K1A5063.JPG";
import nashikroadclinic23 from "./JoshisDentalClinicNahsikRoad/3K1A5064.JPG";
import nashikroadclinic24 from "./JoshisDentalClinicNahsikRoad/3K1A5065.JPG";
import nashikroadclinic25 from "./JoshisDentalClinicNahsikRoad/3K1A5066.JPG";
import nashikroadclinic26 from "./JoshisDentalClinicNahsikRoad/3K1A5067.JPG";
import nashikroadclinic27 from "./JoshisDentalClinicNahsikRoad/3K1A5068.JPG";
import nashikroadclinic28 from "./JoshisDentalClinicNahsikRoad/3K1A5069.JPG";
import nashikroadclinic29 from "./JoshisDentalClinicNahsikRoad/3K1A5070.JPG";
import nashikroadclinic30 from "./JoshisDentalClinicNahsikRoad/3K1A5071.JPG";
import nashikroadclinic31 from "./JoshisDentalClinicNahsikRoad/3K1A5072.JPG";
import nashikroadclinic32 from "./JoshisDentalClinicNahsikRoad/3K1A5073.JPG";
import nashikroadclinic33 from "./JoshisDentalClinicNahsikRoad/3K1A5074.JPG";
import nashikroadclinic34 from "./JoshisDentalClinicNahsikRoad/3K1A5075.JPG";
import nashikroadclinic35 from "./JoshisDentalClinicNahsikRoad/3K1A5076.JPG";
import nashikroadclinic36 from "./JoshisDentalClinicNahsikRoad/3K1A5077.JPG";
import nashikroadclinic37 from "./JoshisDentalClinicNahsikRoad/3K1A5078.JPG";
import nashikroadclinic38 from "./JoshisDentalClinicNahsikRoad/3K1A5079.JPG";
import nashikroadclinic39 from "./JoshisDentalClinicNahsikRoad/3K1A5080.JPG";
import nashikroadclinic40 from "./JoshisDentalClinicNahsikRoad/3K1A5081.JPG";
import nashikroadclinic41 from "./JoshisDentalClinicNahsikRoad/3K1A5082.JPG";
import nashikroadclinic42 from "./JoshisDentalClinicNahsikRoad/3K1A5083.JPG";
import nashikroadclinic43 from "./JoshisDentalClinicNahsikRoad/3K1A5084.JPG";
import nashikroadclinic44 from "./JoshisDentalClinicNahsikRoad/3K1A5085.JPG";
import nashikroadclinic45 from "./JoshisDentalClinicNahsikRoad/3K1A5086.JPG";
import nashikroadclinic46 from "./JoshisDentalClinicNahsikRoad/3K1A5088.JPG";
import nashikroadclinic47 from "./JoshisDentalClinicNahsikRoad/3K1A5089.JPG";
import nashikroadclinic48 from "./JoshisDentalClinicNahsikRoad/3K1A5090.JPG";
import nashikroadclinic49 from "./JoshisDentalClinicNahsikRoad/3K1A5091.JPG";
import nashikroadclinic50 from "./JoshisDentalClinicNahsikRoad/3K1A5092.JPG";
import nashikroadclinic51 from "./JoshisDentalClinicNahsikRoad/3K1A5093.JPG";
import nashikroadclinic52 from "./JoshisDentalClinicNahsikRoad/3K1A5094.JPG";
import nashikroadclinic53 from "./JoshisDentalClinicNahsikRoad/3K1A5095.JPG";
import nashikroadclinic54 from "./JoshisDentalClinicNahsikRoad/3K1A5097.JPG";
import nashikroadclinic55 from "./JoshisDentalClinicNahsikRoad/3K1A5098.JPG";
import nashikroadclinic56 from "./JoshisDentalClinicNahsikRoad/3K1A5100.JPG";
import nashikroadclinic57 from "./JoshisDentalClinicNahsikRoad/3K1A5102.JPG";
import nashikroadclinic58 from "./JoshisDentalClinicNahsikRoad/3K1A5103.JPG";
import nashikroadclinic59 from "./JoshisDentalClinicNahsikRoad/3K1A5104.JPG";
import nashikroadclinic60 from "./JoshisDentalClinicNahsikRoad/3K1A5105.JPG";
import nashikroadclinic61 from "./JoshisDentalClinicNahsikRoad/3K1A5106.JPG";
import nashikroadclinic62 from "./JoshisDentalClinicNahsikRoad/3K1A5107.JPG";
import nashikroadclinic63 from "./JoshisDentalClinicNahsikRoad/3K1A5109.JPG";
import nashikroadclinic64 from "./JoshisDentalClinicNahsikRoad/3K1A5113.JPG";
import nashikroadclinic65 from "./JoshisDentalClinicNahsikRoad/3K1A5114.JPG";
import nashikroadclinic66 from "./JoshisDentalClinicNahsikRoad/3K1A5115.JPG";
import nashikroadclinic67 from "./JoshisDentalClinicNahsikRoad/3K1A5116.JPG";
import nashikroadclinic68 from "./JoshisDentalClinicNahsikRoad/3K1A5117.JPG";
import nashikroadclinic69 from "./JoshisDentalClinicNahsikRoad/3K1A5121.JPG";
import nashikroadclinic70 from "./JoshisDentalClinicNahsikRoad/3K1A5122.JPG";
import nashikroadclinic71 from "./JoshisDentalClinicNahsikRoad/3K1A5123.JPG";
import nashikroadclinic72 from "./JoshisDentalClinicNahsikRoad/3K1A5124.JPG";
import nashikroadclinic73 from "./JoshisDentalClinicNahsikRoad/3K1A5125.JPG";
import nashikroadclinic74 from "./JoshisDentalClinicNahsikRoad/3K1A5126.JPG";
import nashikroadclinic75 from "./JoshisDentalClinicNahsikRoad/3K1A5127.JPG";
import nashikroadclinic76 from "./JoshisDentalClinicNahsikRoad/3K1A5128.JPG";
import nashikroadclinic77 from "./JoshisDentalClinicNahsikRoad/3K1A5129.JPG";
import nashikroadclinic78 from "./JoshisDentalClinicNahsikRoad/3K1A5130.JPG";
import nashikroadclinic79 from "./JoshisDentalClinicNahsikRoad/3K1A5131.JPG";
import nashikroadclinic80 from "./JoshisDentalClinicNahsikRoad/3K1A5132.JPG";
import nashikroadclinic81 from "./JoshisDentalClinicNahsikRoad/3K1A5133.JPG";
import nashikroadclinic82 from "./JoshisDentalClinicNahsikRoad/3K1A5134.JPG";
import nashikroadclinic83 from "./JoshisDentalClinicNahsikRoad/3K1A5135.JPG";
import nashikroadclinic84 from "./JoshisDentalClinicNahsikRoad/3K1A5136.JPG";
import nashikroadclinic85 from "./JoshisDentalClinicNahsikRoad/3K1A5137.JPG";
import nashikroadclinic86 from "./JoshisDentalClinicNahsikRoad/3K1A5138.JPG";
import nashikroadclinic87 from "./JoshisDentalClinicNahsikRoad/3K1A5139.JPG";
import nashikroadclinic88 from "./JoshisDentalClinicNahsikRoad/3K1A5140.JPG";
import nashikroadclinic89 from "./JoshisDentalClinicNahsikRoad/3K1A5141.JPG";
import nashikroadclinic90 from "./JoshisDentalClinicNahsikRoad/3K1A5142.JPG";
import nashikroadclinic91 from "./JoshisDentalClinicNahsikRoad/3K1A5143.JPG";
import nashikroadclinic92 from "./JoshisDentalClinicNahsikRoad/3K1A5144.JPG";
import nashikroadclinic93 from "./JoshisDentalClinicNahsikRoad/3K1A5145.JPG";
import nashikroadclinic94 from "./JoshisDentalClinicNahsikRoad/3K1A5146.JPG";
import nashikroadclinic95 from "./JoshisDentalClinicNahsikRoad/3K1A5147.JPG";
import nashikroadclinic96 from "./JoshisDentalClinicNahsikRoad/3K1A5148.JPG";
import nashikroadclinic97 from "./JoshisDentalClinicNahsikRoad/3K1A5149.JPG";
import nashikroadclinic98 from "./JoshisDentalClinicNahsikRoad/3K1A5150.JPG";
import nashikroadclinic99 from "./JoshisDentalClinicNahsikRoad/3K1A5151.JPG";
import nashikroadclinic100 from "./JoshisDentalClinicNahsikRoad/3K1A5152.JPG";
import nashikroadclinic101 from "./JoshisDentalClinicNahsikRoad/3K1A5154.JPG";
import nashikroadclinic102 from "./JoshisDentalClinicNahsikRoad/3K1A5155.JPG";
import nashikroadclinic103 from "./JoshisDentalClinicNahsikRoad/3K1A5156.JPG";

import clinicnashikroad1 from "./ClinicPhotoshootNashikRoad/1.jpg";
import clinicnashikroad2 from "./ClinicPhotoshootNashikRoad/2.jpg";
import clinicnashikroad3 from "./ClinicPhotoshootNashikRoad/3.jpg";
import clinicnashikroad4 from "./ClinicPhotoshootNashikRoad/4.jpg";
import clinicnashikroad5 from "./ClinicPhotoshootNashikRoad/5.jpg";
import clinicnashikroad6 from "./ClinicPhotoshootNashikRoad/6.jpg";
import clinicnashikroad7 from "./ClinicPhotoshootNashikRoad/7.jpg";
import clinicnashikroad8 from "./ClinicPhotoshootNashikRoad/8.jpg";
import clinicnashikroad9 from "./ClinicPhotoshootNashikRoad/9.jpg";
import clinicnashikroad10 from "./ClinicPhotoshootNashikRoad/10.jpg";
import clinicnashikroad11 from "./ClinicPhotoshootNashikRoad/11.jpg";
import clinicnashikroad12 from "./ClinicPhotoshootNashikRoad/12.jpg";
import clinicnashikroad13 from "./ClinicPhotoshootNashikRoad/13.jpg";
import clinicnashikroad14 from "./ClinicPhotoshootNashikRoad/14.jpg";
import clinicnashikroad15 from "./ClinicPhotoshootNashikRoad/15.jpg";
import clinicnashikroad16 from "./ClinicPhotoshootNashikRoad/16.jpg";
import clinicnashikroad17 from "./ClinicPhotoshootNashikRoad/17.jpg";
import clinicnashikroad18 from "./ClinicPhotoshootNashikRoad/18.jpg";
import clinicnashikroad19 from "./ClinicPhotoshootNashikRoad/19.jpg";
import clinicnashikroad20 from "./ClinicPhotoshootNashikRoad/20.jpg";

export {
  about1,
  about2,
  about3,
  dental,
  drLogo,
  videoHero,
  doctorDiptiJoshi,
  doctorNikitaJoshi,
  doctorPushkarJoshi,
  doctorChinmayJoshi,
  deolalicamptreatment1,
  deolalicamptreatment2,
  deolalicamptreatment3,
  deolalicamptreatment4,
  deolalicamptreatment5,
  deolalicamptreatment6,
  deolalicamptreatment7,
  deolalicamptreatment8,
  deolalicamptreatment9,
  nashikroadclinic1,
  nashikroadclinic2,
  nashikroadclinic3,
  nashikroadclinic4,
  nashikroadclinic5,
  nashikroadclinic6,
  nashikroadclinic7,
  nashikroadclinic8,
  nashikroadclinic9,
  nashikroadclinic10,
  nashikroadclinic11,
  nashikroadclinic12,
  nashikroadclinic13,
  nashikroadclinic14,
  nashikroadclinic15,
  nashikroadclinic16,
  nashikroadclinic17,
  nashikroadclinic18,
  nashikroadclinic19,
  nashikroadclinic20,
  nashikroadclinic21,
  nashikroadclinic22,
  nashikroadclinic23,
  nashikroadclinic24,
  nashikroadclinic25,
  nashikroadclinic26,
  nashikroadclinic27,
  nashikroadclinic28,
  nashikroadclinic29,
  nashikroadclinic30,
  nashikroadclinic31,
  nashikroadclinic32,
  nashikroadclinic33,
  nashikroadclinic34,
  nashikroadclinic35,
  nashikroadclinic36,
  nashikroadclinic37,
  nashikroadclinic38,
  nashikroadclinic39,
  nashikroadclinic40,
  nashikroadclinic41,
  nashikroadclinic42,
  nashikroadclinic43,
  nashikroadclinic44,
  nashikroadclinic45,
  nashikroadclinic46,
  nashikroadclinic47,
  nashikroadclinic48,
  nashikroadclinic49,
  nashikroadclinic50,
  nashikroadclinic51,
  nashikroadclinic52,
  nashikroadclinic53,
  nashikroadclinic54,
  nashikroadclinic55,
  nashikroadclinic56,
  nashikroadclinic57,
  nashikroadclinic58,
  nashikroadclinic59,
  nashikroadclinic60,
  nashikroadclinic61,
  nashikroadclinic62,
  nashikroadclinic63,
  nashikroadclinic64,
  nashikroadclinic65,
  nashikroadclinic66,
  nashikroadclinic67,
  nashikroadclinic68,
  nashikroadclinic69,
  nashikroadclinic70,
  nashikroadclinic71,
  nashikroadclinic72,
  nashikroadclinic73,
  nashikroadclinic74,
  nashikroadclinic75,
  nashikroadclinic76,
  nashikroadclinic77,
  nashikroadclinic78,
  nashikroadclinic79,
  nashikroadclinic80,
  nashikroadclinic81,
  nashikroadclinic82,
  nashikroadclinic83,
  nashikroadclinic84,
  nashikroadclinic85,
  nashikroadclinic86,
  nashikroadclinic87,
  nashikroadclinic88,
  nashikroadclinic89,
  nashikroadclinic90,
  nashikroadclinic91,
  nashikroadclinic92,
  nashikroadclinic93,
  nashikroadclinic94,
  nashikroadclinic95,
  nashikroadclinic96,
  nashikroadclinic97,
  nashikroadclinic98,
  nashikroadclinic99,
  nashikroadclinic100,
  nashikroadclinic101,
  nashikroadclinic102,
  nashikroadclinic103,
  clinicnashikroad1,
  clinicnashikroad2,
  clinicnashikroad3,
  clinicnashikroad4,
  clinicnashikroad5,
  clinicnashikroad6,
  clinicnashikroad7,
  clinicnashikroad8,
  clinicnashikroad9,
  clinicnashikroad10,
  clinicnashikroad11,
  clinicnashikroad12,
  clinicnashikroad13,
  clinicnashikroad14,
  clinicnashikroad15,
  clinicnashikroad16,
  clinicnashikroad17,
  clinicnashikroad18,
  clinicnashikroad19,
  clinicnashikroad20,
};
